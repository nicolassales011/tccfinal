import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('HTML mostra criação ao motorista e edição, exclusão e aprovação ao administrador',async()=>{
 const base=new URL('../public/',import.meta.url);
 const names=JSON.parse(await readFile(new URL('html/manifest.json',base),'utf8'));
 const templates=new Map(await Promise.all(names.map(async name=>[name,await readFile(new URL('html/'+name+'.html',base),'utf8')])));
 const html=(name,values=[])=>{assert.ok(templates.has(name),name);return templates.get(name).replace(/\{\{(\d+)\}\}/g,(_,n)=>String(values[+n]??''));};
 const script=await readFile(new URL('js/interacoes.js',base),'utf8');
 const prefix=script.slice(script.indexOf('const $='),script.indexOf('try{await refresh();const token='));
 const document={querySelector(){return {addEventListener(){}};},addEventListener(){}};
 const ui=Function('document','window','location','html',prefix+`;return {setup(s,a){state=s;admin=a;},tab(v){adminTab=v;},trips,adminPage};`)(document,{addEventListener(){}},{hash:'#buscar'},html);
 const event={id:'e',name:'Evento teste',date:'2027-01-01T20:00:00Z',approval:'pendente',location:'Santos'};
 const trip=status=>({id:status,status,date:'2027-01-01T17:00:00Z',event,driver:{name:'Motorista'},origin:'Santos',destination:'São Paulo',capacity:3,available:3,price:20,approval:status==='agendada'?'pendente':'aprovada',passengers:[]});
 const trips=['agendada','cancelada','concluida'].map(trip);
 ui.setup({user:{id:'d',role:'motorista'},myTrips:trips,myEvents:[event]}, {users:[],trips,events:[event],reservations:[]});
 const driver=ui.trips();assert.match(driver,/Criar viagem/);assert.match(driver,/Propor evento/);assert.match(driver,/Aguardando aprovação/);assert.ok(!driver.includes('{{'));
 ui.tab('trips');const list=ui.adminPage();assert.equal((list.match(/data-action="edit-trip"/g)||[]).length,3);assert.equal((list.match(/data-action="delete-trip"/g)||[]).length,3);
 ui.tab('approvals');const approvals=ui.adminPage();assert.equal((approvals.match(/data-action="approve"/g)||[]).length,2);assert.match(approvals,/data-kind="event"/);assert.match(approvals,/data-kind="trip"/);
 ui.tab('events');assert.match(ui.adminPage(),/Aguardando aprovação/);
});
