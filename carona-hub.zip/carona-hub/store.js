import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import { scryptSync, randomBytes, timingSafeEqual, randomUUID } from 'node:crypto';
export const id = () => randomUUID();
export function hash(password) { const salt = randomBytes(16).toString('hex'); return salt + ':' + scryptSync(password, salt, 64).toString('hex'); }
export function verify(password, value) { const [salt, key] = value.split(':'); return timingSafeEqual(Buffer.from(key, 'hex'), scryptSync(password, salt, 64)); }
export function validCPF(value) {
  const cpf = String(value).replace(/\D/g, '');
  if (!/^\d{11}$/.test(cpf) || /^(\d)\1{10}$/.test(cpf)) return false;
  for (let size = 9; size <= 10; size++) { let sum = 0; for (let i = 0; i < size; i++) sum += Number(cpf[i]) * (size + 1 - i); const digit = (sum * 10 % 11) % 10; if (digit !== Number(cpf[size])) return false; }
  return true;
}
function seed() {
 const users = [ ['p1','Marina Costa','passageiro'], ['d1','Lucas Almeida','motorista'], ['a1','Administrador','admin'] ].map(([id,name,role]) => ({id,name,role,email:role+'@caronahub.local',password:hash('Carona@123'),phone:'13999999999',cpf:'',active:true,vehicle:'Honda Civic',plate:'ABC1D23',color:'Prata',cnh:'12345678901',createdAt:new Date().toISOString()}));
 const future = days => { const d=new Date(); d.setDate(d.getDate()+days); d.setHours(20,0,0,0); return d.toISOString(); };
 const events = [ ['e1','Festival Horizonte','Música','Allianz Parque, São Paulo',12], ['e2','Clássico na Arena','Esporte','Neo Química Arena, São Paulo',18], ['e3','Encontro de Cultura Urbana','Cultura','Memorial da América Latina, São Paulo',25] ].map(([id,name,category,location,days])=>({id,name,category,location,date:future(days),description:'Evento fictício para demonstração do projeto acadêmico.'}));
 const trips = events.map((e,i)=>({id:'t'+(i+1),driverId:'d1',eventId:e.id,origin:['Santos','Praia Grande','Mongaguá'][i],destination:e.location,date:new Date(new Date(e.date).getTime()-10800000).toISOString(),capacity:[3,4,3][i],price:[45,55,40][i],notes:'Ponto de encontro em frente à rodoviária. Chegue 10 minutos antes da saída.',status:'agendada'}));
 return {users,events,trips,reservations:[],reviews:[],notifications:[],sessions:[],resets:[],logs:[]};
}
let pool; let queue=Promise.resolve();
const collections = [
 ['users','tb_usuario',['id','name','email','password','cpf','phone','role','active','vehicle','plate','color','cnh','createdAt']],
 ['events','tb_evento',['id','name','category','location','date','description','approval','createdBy']],
 ['trips','tb_viagem',['id','driverId','eventId','origin','destination','date','capacity','price','notes','status','approval','deleted']],
 ['reservations','tb_reserva',['id','tripId','userId','quantity','status','date']],
 ['reviews','tb_avaliacao',['id','reservationId','tripId','rating','comment','date']],
 ['notifications','tb_notificacao',['id','userId','message','date','read']]
];
async function saveSQL(c,db) {
 for(const e of db.events)e.approval??='aprovada';for(const t of db.trips){t.approval??='aprovada';t.deleted??=false;}
 for(const [key,table] of [...collections].reverse()) {
  const ids=db[key].map(row=>row.id);
  if(ids.length)await c.execute(`DELETE FROM ${table} WHERE id NOT IN (${ids.map(()=>'?').join(',')})`,ids);
  else await c.query(`DELETE FROM ${table}`);
 }
 for(const [key,table,fields] of collections)for(const row of db[key]) {
  const columns=fields.map(f=>'`'+f+'`').join(',');
  await c.execute(`INSERT INTO ${table} (${columns}) VALUES (${fields.map(()=>'?').join(',')}) ON DUPLICATE KEY UPDATE ${fields.filter(f=>f!=='id').map(f=>'`'+f+'`=VALUES(`'+f+'`)').join(',')}`,fields.map(f=>row[f]??null));
 }
 await c.execute('UPDATE app_meta SET payload=? WHERE id=1',[JSON.stringify({sessions:db.sessions,resets:db.resets,logs:db.logs})]);
}
const directory = process.env.DATA_DIR || new URL('./data/',import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1');
export async function initialize() {
 if(process.env.STORAGE==='mysql') {
  const mysql=await import('mysql2/promise');
  pool=mysql.createPool({host:process.env.MYSQL_HOST||'127.0.0.1',port:Number(process.env.MYSQL_PORT||3306),user:process.env.MYSQL_USER||'root',password:process.env.MYSQL_PASSWORD||'',database:process.env.MYSQL_DATABASE||'carona_hub',connectionLimit:5,decimalNumbers:true});
  const sql=(await readFile(new URL('./database/schema.sql',import.meta.url),'utf8')).split('-- TABLES')[1];
  for(const statement of sql.split(';').map(s=>s.trim()).filter(Boolean))await pool.query(statement);
  for(const [table,columns] of [['tb_evento',{approval:"VARCHAR(20) NOT NULL DEFAULT 'aprovada'",createdBy:'VARCHAR(36) NULL'}],['tb_viagem',{approval:"VARCHAR(20) NOT NULL DEFAULT 'aprovada'",deleted:'BOOLEAN NOT NULL DEFAULT FALSE'}]]){const [existing]=await pool.query('SHOW COLUMNS FROM '+table);for(const [column,definition] of Object.entries(columns))if(!existing.some(c=>c.Field===column))await pool.query('ALTER TABLE '+table+' ADD COLUMN '+column+' '+definition);}
  await pool.execute('INSERT IGNORE INTO app_meta (id,payload) VALUES (1,?)',[JSON.stringify({sessions:[],resets:[],logs:[]})]);
  const c=await pool.getConnection();try{await c.beginTransaction();await c.query('SELECT id FROM app_meta WHERE id=1 FOR UPDATE');const [rows]=await c.query('SELECT COUNT(*) AS total FROM tb_usuario');if(!rows[0].total)await saveSQL(c,seed());await c.commit();}catch(e){await c.rollback();throw e;}finally{c.release();}
 } else { await mkdir(directory,{recursive:true}); try{await readFile(directory+'/state.json');}catch(e){if(e.code!=='ENOENT')throw e;await writeFile(directory+'/state.json',JSON.stringify(seed(),null,2));} }
}
export function transaction(fn) {
 const task=queue.then(async()=>{
  if(pool){ const c=await pool.getConnection();try{await c.beginTransaction();const [rows]=await c.query('SELECT payload FROM app_meta WHERE id=1 FOR UPDATE');const db=typeof rows[0].payload==='string'?JSON.parse(rows[0].payload):rows[0].payload;for(const [key,table] of collections){const [records]=await c.query(`SELECT * FROM ${table}`);db[key]=records.map(row=>({...row,...(key==='users'?{active:Boolean(row.active)}:{}),...(key==='notifications'?{read:Boolean(row.read)}:{})}));}const result=await fn(db);await saveSQL(c,db);await c.commit();return result;}catch(e){await c.rollback();throw e;}finally{c.release();} }
  const db=JSON.parse(await readFile(directory+'/state.json','utf8'));const result=await fn(db);await writeFile(directory+'/state.tmp',JSON.stringify(db,null,2));await rename(directory+'/state.tmp',directory+'/state.json');return result;
 });queue=task.catch(()=>{});return task;
}
