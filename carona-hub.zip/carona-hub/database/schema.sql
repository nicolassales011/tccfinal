CREATE DATABASE IF NOT EXISTS carona_hub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE carona_hub;
-- TABLES
CREATE TABLE IF NOT EXISTS tb_usuario (
 id VARCHAR(36) PRIMARY KEY,
 name VARCHAR(200) NOT NULL,
 email VARCHAR(200) NOT NULL UNIQUE,
 password VARCHAR(200) NOT NULL,
 cpf VARCHAR(11), phone VARCHAR(20),
 role ENUM('passageiro','motorista','admin') NOT NULL,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 vehicle VARCHAR(200), plate VARCHAR(10), color VARCHAR(200), cnh VARCHAR(20),
 createdAt VARCHAR(30) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tb_evento (
 id VARCHAR(36) PRIMARY KEY,
 name VARCHAR(200) NOT NULL,
 category VARCHAR(200) NOT NULL,
 location VARCHAR(200) NOT NULL,
 date VARCHAR(30) NOT NULL,
 description TEXT,
 approval VARCHAR(20) NOT NULL DEFAULT 'aprovada',
 createdBy VARCHAR(36) NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tb_viagem (
 id VARCHAR(36) PRIMARY KEY,
 driverId VARCHAR(36) NOT NULL,
 eventId VARCHAR(36) NOT NULL,
 origin VARCHAR(200) NOT NULL,
 destination VARCHAR(200) NOT NULL,
 date VARCHAR(30) NOT NULL,
 capacity INT NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 notes TEXT,
 status ENUM('agendada','cancelada','concluida') NOT NULL,
 approval VARCHAR(20) NOT NULL DEFAULT 'aprovada',
 deleted BOOLEAN NOT NULL DEFAULT FALSE,
 FOREIGN KEY (driverId) REFERENCES tb_usuario(id),
 FOREIGN KEY (eventId) REFERENCES tb_evento(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tb_reserva (
 id VARCHAR(36) PRIMARY KEY,
 tripId VARCHAR(36) NOT NULL,
 userId VARCHAR(36) NOT NULL,
 quantity INT NOT NULL,
 status ENUM('confirmada','cancelada') NOT NULL,
 date VARCHAR(30) NOT NULL,
 FOREIGN KEY (tripId) REFERENCES tb_viagem(id),
 FOREIGN KEY (userId) REFERENCES tb_usuario(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tb_avaliacao (
 id VARCHAR(36) PRIMARY KEY,
 reservationId VARCHAR(36) NOT NULL UNIQUE,
 tripId VARCHAR(36) NOT NULL,
 rating INT NOT NULL,
 comment TEXT,
 date VARCHAR(30) NOT NULL,
 FOREIGN KEY (reservationId) REFERENCES tb_reserva(id),
 FOREIGN KEY (tripId) REFERENCES tb_viagem(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tb_notificacao (
 id VARCHAR(36) PRIMARY KEY,
 userId VARCHAR(36) NOT NULL,
 message TEXT NOT NULL,
 date VARCHAR(30) NOT NULL,
 `read` BOOLEAN NOT NULL DEFAULT FALSE,
 FOREIGN KEY (userId) REFERENCES tb_usuario(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS app_meta (
 id INT PRIMARY KEY,
 payload JSON NOT NULL
) ENGINE=InnoDB;
