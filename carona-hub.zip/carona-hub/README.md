# Carona Hub — MobilityTech

Sistema local de transporte compartilhado para eventos, desenvolvido com base no arquivo **TCC MOBILITYTECH 03-08.docx**. Interface em português, preta e laranja, adaptável a celular, tablet e computador.

O projeto usa **HTML, CSS, JavaScript e MySQL**, as tecnologias de implementação indicadas no TCC. O servidor foi acrescentado em **Node.js**, usando JavaScript também no backend. O documento menciona Visual Studio e .NET como contexto do ambiente, mas não define uma linguagem de servidor. Esta entrega é preparada para o **VS Code**, conforme solicitado.

## Atualização: aprovação de viagens e eventos

- **Motorista → Minhas viagens → Criar viagem:** envia uma viagem pendente para um evento já aprovado. Ela só aparece na busca e aceita reservas depois da aprovação administrativa.
- **Motorista → Propor evento:** envia um evento para análise. A situação aparece em Meus eventos propostos. Após a aprovação, o motorista pode selecioná-lo em uma viagem.
- **Administrador → Aprovações:** reúne eventos e viagens pendentes, com botões Aprovar e Rejeitar. O autor recebe uma notificação interna.
- **Administrador → Viagens:** permite editar e excluir todas as viagens, inclusive canceladas, concluídas ou com data passada. Editar não reabre uma viagem encerrada. A exclusão remove a viagem das listagens e cancela reservas confirmadas, preservando os registros para histórico e notificando os envolvidos.
- **Administrador → Eventos:** permite cadastrar, editar e analisar eventos. Eventos novos, inclusive os cadastrados pelo administrador, começam pendentes e precisam da ação explícita Aprovar.
- Alterações feitas pelo motorista em uma viagem voltam para aprovação. Reservas já existentes permanecem registradas e recebem aviso da alteração, mas novas reservas ficam bloqueadas até a aprovação. Uma viagem rejeitada pode ser editada pelo motorista e reenviada.
- Viagens e eventos da versão anterior permanecem aprovados. Os novos estados são salvos tanto no modo JSON quanto no MySQL.

### Atualizar sem perder seus dados

Encerre o servidor antigo com Ctrl+C antes de executar a nova versão. Extraia o novo ZIP em outra pasta. Se utiliza o modo local, copie a pasta `data` da versão anterior para a nova; copie também `.env` se existir. Não substitua sua pasta `data` por outra base de demonstração. Execute `node start.js` na nova pasta e atualize o navegador.

No MySQL, a aplicação adiciona automaticamente as colunas de aprovação e exclusão quando estiverem ausentes, preservando os registros existentes. A conta usada nessa primeira inicialização precisa de permissão ALTER nas tabelas `tb_evento` e `tb_viagem`, além das permissões anteriores. O arquivo `database/schema.sql` também já contém as colunas para instalações novas. A conexão MySQL não foi testada neste ambiente; a suíte de testes valida os fluxos no armazenamento JSON.

## Organização desta versão com HTML separado

A estrutura das telas saiu de `app.js`. Esse arquivo não existe nesta versão.

- `public/index.html`: documento principal, área de conteúdo e janela modal.
- `public/html/buscar.html`: estrutura da busca de caronas.
- `public/html/eventos.html`, `reservas.html`, `viagens.html`, `perfil.html` e `administracao.html`: estrutura das respectivas telas.
- `public/html/login.html` e `cadastro.html`: estrutura dos formulários de acesso.
- `public/html/componentes/`: trechos reutilizáveis, como opções, mensagens e ações.
- `public/style.css`: todo o visual e a responsividade.
- `public/js/interacoes.js`: preenche os dados e responde aos cliques e formulários.
- `public/js/html.js`: carrega os arquivos HTML e substitui seus pontos de preenchimento.

Os marcadores `{{0}}`, `{{1}}` etc. recebem dados calculados pelo JavaScript. Para alterar títulos, textos estáticos, classes e estrutura, edite o HTML. Para mudar as regras de interação, edite o JavaScript. Preserve os marcadores quando estiver apenas ajustando o layout. Valores de usuários continuam escapados antes da inserção.

As telas são fragmentos HTML carregados dentro do documento principal, mantendo a navegação existente. Elas não são páginas independentes que funcionam com duplo clique. Inicie com `node start.js` e abra o endereço do servidor. A integração MySQL e os dados continuam no backend Node.js.

O pacote passou pelos testes de autenticação, permissões, reservas e persistência, pelos testes HTTP dos novos arquivos e por uma comparação da saída das telas e formulários antes/depois da separação.

## 1. Rodar agora no VS Code

1. Instale o [Node.js](https://nodejs.org/en/download) versão **22.9 ou superior**, com a opção de adicionar ao PATH. O projeto foi testado com Node.js **24.19.0**.
2. Extraia o ZIP. No VS Code, vá a **Arquivo → Abrir Pasta** e selecione a pasta `carona-hub` que contém `server.js` e este guia.
3. Abra **Terminal → Novo Terminal**.
4. Confirme a instalação:

   ```powershell
   node --version
   ```

5. Execute:

   ```powershell
   node start.js
   ```

6. Abra **http://localhost:3000** no navegador. Mantenha o terminal aberto.
7. Para encerrar, pressione **Ctrl+C** no terminal.

Esse caminho funciona **sem instalar pacotes e sem configurar MySQL**. Por padrão, o servidor guarda os dados de demonstração em `data/state.json`, e os cadastros e reservas continuam disponíveis ao reiniciar. Isso é um modo local de demonstração, não uma conexão MySQL disfarçada.

Também é possível pressionar **F5** no VS Code e escolher **Iniciar Carona Hub**, ou dar dois cliques em `INICIAR.cmd` no Windows. O F5 e o iniciador leem `.env` se existir. O iniciador `node start.js` também lê `.env`, verifica os arquivos necessários e informa quando o site já está em execução.

Não abra `index.html` diretamente e não use a extensão Live Server para este projeto: login, reservas e banco dependem do servidor Node.js.

## 2. Contas prontas para testar

| Perfil | E-mail | Senha inicial |
| --- | --- | --- |
| Passageiro | passageiro@caronahub.local | Carona@123 |
| Motorista | motorista@caronahub.local | Carona@123 |
| Administrador | admin@caronahub.local | Carona@123 |

Na janela de login, os botões de demonstração preenchem e acessam essas contas. Os eventos, veículos e pessoas iniciais são fictícios. As datas são geradas no primeiro início, sempre alguns dias à frente. Administradores podem cadastrar novos eventos conforme necessário. Não existe validação externa de CNH ou identidade.

Para ver os dois lados de uma reserva, use uma janela normal como passageiro e uma janela anônima como motorista. Na mesma janela, sair e entrar com outra conta também funciona.

## 3. Usar MySQL de verdade

### Preparar o banco

1. Instale e inicie o **MySQL Server 8 ou superior**, além do MySQL Workbench, se quiser uma interface para executar SQL. [Downloads oficiais do MySQL](https://dev.mysql.com/downloads/).
2. Conecte-se ao servidor pelo Workbench.
3. Abra `database/schema.sql` e execute o arquivo inteiro. Ele cria o banco `carona_hub` e suas tabelas sem apagar tabelas existentes.
4. Crie uma conta exclusiva para este banco. Execute como administrador do MySQL, substituindo a senha do exemplo por uma senha sua:

   ```sql
   CREATE USER 'carona_app'@'localhost' IDENTIFIED BY 'Troque_Esta_Senha_123!';
   GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, REFERENCES
   ON carona_hub.* TO 'carona_app'@'localhost';
   ```

### Configurar o projeto

No terminal do VS Code, dentro da pasta do projeto:

```powershell
npm.cmd install
Copy-Item .env.example .env
```

No Windows, `npm.cmd` evita o bloqueio do script `npm.ps1` em instalações com política de PowerShell restrita. Em macOS ou Linux, use `npm install` e copie `.env.example` para `.env` pelo editor.

Edite `.env`:

```dotenv
PORT=3000
STORAGE=mysql
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=carona_app
MYSQL_PASSWORD="Troque_Esta_Senha_123!"
MYSQL_DATABASE=carona_hub
APP_URL=http://localhost:3000
```

Use no campo de senha o mesmo valor definido no MySQL. Coloque entre aspas valores que contenham `#`.

Inicie com:

```powershell
node --env-file-if-exists=.env server.js
```

Ou use `npm.cmd start` / F5. O terminal deve mostrar **Armazenamento: MySQL**. As contas e os eventos de demonstração são criados quando o banco ainda não contém usuários.

Os modos JSON e MySQL têm dados independentes. Alterar `STORAGE` não migra os registros automaticamente. As tabelas do projeto devem ficar em um banco dedicado.

### Como o banco está organizado

| Tabela | Conteúdo |
| --- | --- |
| tb_usuario | Cadastro, hash da senha, perfil, situação e veículo do motorista |
| tb_evento | Eventos, local, categoria e data |
| tb_viagem | Motorista, evento, trajeto, capacidade, valor e situação |
| tb_reserva | Passageiro, viagem, quantidade de vagas e situação |
| tb_avaliacao | Nota e comentário vinculados à reserva |
| tb_notificacao | Mensagens de cada usuário e marcação de leitura |
| app_meta | Sessões, tokens temporários de recuperação e registro de ações |

O modelo adapta o MER do TCC: reúne passageiros e motoristas em `tb_usuario` com um campo de perfil, usa identificadores UUID e acrescenta os campos de estado, quantidade e notificação necessários aos fluxos. As colunas usam os mesmos nomes dos objetos JavaScript. Datas são armazenadas como texto ISO 8601 em UTC e apresentadas no fuso do navegador.

Chaves estrangeiras protegem os vínculos. Uma transação com bloqueio central serializa a leitura, a validação e a gravação das operações, evitando ocupação excessiva das vagas. A persistência carrega e sincroniza as coleções completas: é uma implementação voltada a demonstrações e pequenos conjuntos de dados. Para grande volume, substitua por consultas e atualizações por registro, paginação e bloqueios por viagem.

## 4. Como usar cada área

### Passageiro

1. Entre na conta ou crie um cadastro de passageiro.
2. Filtre as caronas por cidade de saída, evento, data ou categoria. Ordene por data ou preço.
3. Abra a seta de uma carona para ver motorista, veículo, saída, destino e orientações.
4. Escolha a quantidade de vagas e confirme a reserva.
5. Em **Minhas reservas**, consulte os detalhes ou cancele antes da saída. O cancelamento devolve as vagas e gera notificações.
6. Após o motorista concluir a viagem, avalie de 1 a 5 estrelas. Cada reserva aceita uma avaliação.

Não há pagamento eletrônico. O valor exibido é o custo combinado com o motorista.

### Motorista

1. Entre como motorista ou cadastre uma conta com CNH e dados do veículo.
2. Selecione **Criar viagem** e um evento aprovado. Se necessário, use **Propor evento** e aguarde a aprovação primeiro.
3. Preencha origem, destino, saída, total de vagas para passageiros, preço e ponto de encontro e envie para aprovação.
4. Em **Minhas viagens**, acompanhe os nomes e quantidades reservadas.
5. Edite ou cancele antes do horário da saída. Alterações geram avisos para os passageiros. A capacidade não pode ficar abaixo da quantidade já reservada.
6. Após o horário da saída, use **Concluir viagem** para liberar as avaliações.

### Administrador

Na área **Administração**, consulte usuários e bloqueie/desbloqueie o acesso, gerencie viagens, crie/edite/exclua eventos sem viagens vinculadas e cancele reservas válidas. O bloqueio de uma conta encerra suas sessões. A própria conta administrativa não pode ser bloqueada por esse botão.

Em **Relatórios**, filtre as reservas pelo período de criação, exporte **CSV compatível com Excel**, ou clique em **Salvar PDF** e escolha **Salvar como PDF** na janela de impressão do navegador. A exportação é CSV, não um arquivo XLSX; o PDF usa a impressão do navegador.

### Perfil e notificações

Clique nas iniciais da conta para editar nome, telefone, e-mail e senha. A troca de senha exige a senha atual. Em **Avisos**, consulte confirmações, cancelamentos e alterações e marque as mensagens como lidas. As notificações são internas, atualizadas ao navegar ou recarregar a página; não são push, WhatsApp ou SMS.

## 5. Recuperar senha

Clique em **Entrar → Esqueci minha senha** e informe um e-mail cadastrado.

Sem SMTP, o servidor escreve um link **somente no terminal local**. Copie esse link para o navegador, escolha uma nova senha e faça login. O link expira em 15 minutos e só pode ser usado uma vez. A tela não revela se determinado e-mail existe.

Para enviar e-mail real, instale as dependências e preencha os campos seguintes em `.env` com os dados do seu provedor:

```dotenv
SMTP_HOST=smtp.seu-provedor.com
SMTP_PORT=587
SMTP_USER=seu-usuario
SMTP_PASSWORD="sua-senha-ou-senha-de-aplicativo"
SMTP_FROM="Carona Hub <seu-email@seu-dominio.com>"
APP_URL=http://localhost:3000
```

Reinicie o servidor. A porta 465 usa TLS direto; a 587 utiliza a configuração normal de SMTP com STARTTLS quando oferecido pelo servidor. O endereço local do link só funciona no computador que está executando o projeto. As credenciais de SMTP não estão incluídas.

## 6. Editar o código

```text
carona-hub/
  public/
    index.html         Estrutura da página e janela modal
    style.css          Cores, tipografia e regras responsivas
    html/              Estrutura HTML das telas e componentes
    js/interacoes.js   Dados, eventos, formulários e chamadas à API
    js/html.js         Carregamento dos arquivos HTML
    favicon.svg        Ícone da aplicação
  database/schema.sql  Tabelas e relacionamentos MySQL
  start.js             Inicialização e diagnóstico de arquivos/conexão
  server.js            Servidor HTTP, validações e regras de negócio
  store.js             Persistência JSON/MySQL, dados iniciais e senhas
  tests/app.test.js     Testes automatizados dos fluxos
  .vscode/launch.json   Inicialização pelo F5
  .env.example         Modelo de configuração
  INICIAR.cmd          Inicialização no Windows
  package.json         Scripts e dependências opcionais para MySQL/SMTP
```

As cores principais ficam no começo de `public/style.css`, em `:root`: `--bg`, `--panel` e `--orange`. Os pontos de adaptação do layout são 1050, 740 e 420 pixels. O site inclui foco visível, rótulos de formulário, navegação por teclado, modal nativo, redução de movimento e estilo de impressão.

Durante a edição, use:

```powershell
node --watch --env-file-if-exists=.env server.js
```

Recarregue o navegador para ver alterações no frontend. Não há compilação ou etapa de build: o servidor entrega diretamente HTML, CSS e JavaScript. Para usar GitHub, inicialize um repositório na pasta e publique o código pelo VS Code; `.gitignore` exclui senhas locais, dados e dependências. Nenhum repositório externo foi criado nesta entrega.

## 7. Testes e limites verificados

Execute, sem precisar de MySQL:

```powershell
node --test tests/*.test.js
```

A suíte inicia um servidor isolado na porta 31387 e verifica CPF, senhas com salt, login, permissões, bloqueio de origem externa, cadastro duplicado, reserva concorrente, devolução de vagas, edição e cancelamento de viagem, notificações, eventos administrativos, perfil, persistência após reiniciar e recuperação de senha de uso único.

**Validação realizada:** testes automatizados no armazenamento JSON, análise de sintaxe dos arquivos JavaScript, resposta HTTP da página e dos arquivos de estilo/script, inicialização e inspeção das telas no navegador. **Não validado neste ambiente:** conexão com um servidor MySQL, entrega SMTP real, recursos experimentais de integração com agentes e testes em dispositivos físicos. As telas de busca, eventos e administração foram conferidas no navegador integrado, incluindo uma inspeção visual em janela estreita; essa verificação não substitui testes em todos os navegadores e tamanhos de tela.

A implementação cobre os fluxos principais RF01–RF10 e acrescenta avaliações, notificações, eventos e relatório de reservas. Algumas extensões mencionadas nos casos de uso do documento não fazem parte desta versão: foto de perfil, relatórios específicos de todas as entidades e exportação XLSX nativa. Cancelamentos mantêm o histórico em vez de excluir os registros de viagem.

Este pacote está configurado para uso local: o servidor escuta apenas em `127.0.0.1`. As contas de demonstração e seus atalhos estão habilitados. Uma publicação para usuários reais exige retirar esses atalhos e credenciais, configurar HTTPS e cookies Secure, revisar tratamento de dados e substituir o armazenamento de demonstração. Não houve publicação externa.

## 8. Soluções rápidas

| Situação | Solução |
| --- | --- |
| `node` não reconhecido | Instale Node.js e reabra o VS Code para atualizar o PATH. |
| Opção `--env-file-if-exists` desconhecida | Atualize para Node.js 22.9 ou superior. |
| Porta 3000 ocupada (`EADDRINUSE`) | Encerre a outra instância ou defina `PORT=3001` e `APP_URL=http://localhost:3001` em `.env`. Execute com carregamento de `.env`. |
| Site não abre | Confirme a mensagem de início no terminal e use `http://localhost:3000`, não `https`. |
| `Cannot find package mysql2` ou `nodemailer` | Execute `npm.cmd install` na pasta do projeto. |
| MySQL `ECONNREFUSED` | Inicie o MySQL Server e confirme host e porta. |
| MySQL `Access denied` | Confira usuário, senha e permissões para o banco configurado. |
| MySQL `Unknown database` | Execute o arquivo `database/schema.sql`. |
| Testes acusam porta em uso | Encerre outra execução da suíte na porta 31387 e tente novamente. |
| Viagens antigas sumiram da busca | A busca mostra apenas viagens futuras; cadastre novos eventos e viagens. |
| Quero começar de novo no modo demo | Pare o servidor e renomeie a pasta `data` para `data-backup`. O próximo início cria outra base, preservando a cópia antiga. |

Referências técnicas: [opções de execução e arquivos de ambiente do Node.js](https://nodejs.org/api/cli.html#--env-file-if-existsfile) e [criação de contas e permissões no MySQL](https://dev.mysql.com/doc/refman/8.0/en/creating-accounts.html).
