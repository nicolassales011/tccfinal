import { access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { loadEnvFile } from 'node:process';

// Inicializa sempre a partir da pasta deste arquivo, inclusive pelo VS Code.
process.chdir(fileURLToPath(new URL('.', import.meta.url)));
try {
  try { loadEnvFile('.env'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  for (const file of ['server.js', 'store.js', 'public/index.html', 'public/style.css', 'public/js/interacoes.js', 'public/js/html.js', 'public/html/manifest.json', 'public/favicon.svg', 'database/schema.sql']) {
    try { await access(new URL(file, import.meta.url)); }
    catch { throw new Error(`Arquivo ausente: ${file}. Extraia novamente o ZIP inteiro antes de iniciar.`); }
  }
  const port = Number(process.env.PORT || 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT deve ser um número entre 1 e 65535.');
  const url = `http://localhost:${port}`;
  let existing = false;
  try {
    const response = await fetch(`${url}/api/state`, { signal: AbortSignal.timeout(1500) });
    const data = await response.json();
    existing = response.ok && Array.isArray(data.events) && Array.isArray(data.trips) && ['demo', 'mysql'].includes(data.mode);
  } catch { /* Sem instância ativa: iniciar abaixo. */ }
  if (existing) console.log(`\nO Carona Hub já está funcionando.\nAbra ${url}\nNão é necessário iniciar uma segunda instância.\n`);
  else {
    console.log('\nMantenha este terminal aberto enquanto utilizar o site.\nPara encerrar, pressione Ctrl+C.\n');
    await import('./server.js');
  }
} catch (error) {
  console.error(`\nNão foi possível iniciar o Carona Hub.\n${error.message}\nConsulte LEIA-PRIMEIRO.txt ou README.md.\n`);
  process.exitCode = 1;
}
