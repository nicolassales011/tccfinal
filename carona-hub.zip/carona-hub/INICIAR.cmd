@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Instale o Node.js 22.9 ou superior e abra este arquivo novamente.
  pause
  exit /b 1
)
echo Abra http://localhost:3000 no navegador depois que o servidor iniciar.
node start.js
pause
