import { html, carregarHTML } from './html.js';

await carregarHTML();

const $ = (s) => document.querySelector(s);
const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));

const money = (v) =>
  new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(v);

const date = (v) =>
  new Date(v).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'short'
  });

const time = (v) =>
  new Date(v).toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit'
  });

const fullDate = (v) =>
  new Date(v).toLocaleString('pt-BR', {
    dateStyle: 'short',
    timeStyle: 'short'
  });

const initials = (name) =>
  esc(name?.split(' ').slice(0, 2).map((n) => n[0]).join('') || '?');

const localDate = (v) => {
  const d = new Date(v);
  return new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

let state,
  admin,
  category = 'Todos',
  adminTab = 'approvals',
  filters = { origin: '', eventId: '', date: '' },
  sort = 'date',
  toastTimer;

async function api(route, body) {
  let r;

  try {
    r = await fetch(`/api/${route}`, {
      method: body === undefined ? 'GET' : 'POST',
      headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(8000)
    });
  } catch {
    throw Error(
      'Servidor local indisponível. Execute node start.js na pasta carona-hub, mantenha o terminal aberto e tente novamente.'
    );
  }

  let data;

  try {
    data = await r.json();
  } catch {
    throw Error(
      'Abra o site pelo servidor Node.js em http://localhost:3000. Live Server e index.html aberto diretamente não iniciam o sistema.'
    );
  }

  if (!r.ok) {
    throw Error(data.error || 'Não foi possível concluir.');
  }

  return data;
}

function connectionFailure(error) {
  $('#main').innerHTML = html('componentes/conexao-002', [
    empty('O servidor local não está respondendo.',
      html('componentes/conexao-001', [esc(error.message)]))
  ]);
}

function toast(message) {
  $('#toast').textContent = message;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    $('#toast').textContent = '';
  }, 6500);
}

function modal(content) {
  $('#modal-content').innerHTML = content;

  if (!$('#modal').open) {
    $('#modal').showModal();
  }
}

function close() {
  $('#modal').close();
}

$('#close-modal').onclick = close;
$('#modal').addEventListener('click', (e) => {
  if (e.target === $('#modal')) {
    const r = e.target.getBoundingClientRect();

    if (
      e.clientX < r.left ||
      e.clientX > r.right ||
      e.clientY < r.top ||
      e.clientY > r.bottom
    ) {
      close();
    }
  }
});

const route = () => location.hash.slice(1) || 'buscar';
const empty = (title, body) => html('componentes/close-003', [title, body]);
const field = (label, name, type = 'text', value = '', extra = '') =>
  html('componentes/close-004', [label, name, type, esc(value), extra]);
const errorSlot = html('componentes/close-005', []);
const eventOptions = (selected = '') =>
  (state.user?.role === 'admin' && admin ? admin.events : state.events)
    .map((e) =>
      html('componentes/close-006', [
        e.id,
        selected === e.id ? 'selected' : '',
        esc(e.name)
      ])
    )
    .join('');

function header() {
  const u = state.user;
  const links = [['buscar', 'Buscar caronas'], ['eventos', 'Eventos']];

  if (u?.role === 'passageiro') {
    links.push(['reservas', 'Minhas reservas']);
  }

  if (u?.role === 'motorista') {
    links.push(['viagens', 'Minhas viagens']);
  }

  if (u?.role === 'admin') {
    links.push(['admin', 'Administração']);
  }

  $('#header').innerHTML = html('componentes/cabecalho-011', [
    links
      .map(([r, n]) =>
        html('componentes/cabecalho-007', [
          r,
          route() === r ? 'active' : '',
          route() === r ? 'aria-current="page"' : '',
          n
        ])
      )
      .join(''),
    u
      ? html('cabecalho', [
          state.notifications.filter((n) => !n.read).length
            ? html('componentes/cabecalho-008', [
                state.notifications.filter((n) => !n.read).length
              ])
            : '',
          initials(u.name),
          esc(u.name.split(' ')[0])
        ])
      : html('componentes/cabecalho-010', [])
  ]);
}

function tripCard(t) {
  return html('cartao-carona', [
    esc(t.event?.category || 'Evento'),
    date(t.date),
    time(t.date),
    esc(t.event?.name || 'Evento'),
    time(t.date),
    esc(t.origin),
    esc(t.destination),
    initials(t.driver.name),
    esc(t.driver.name),
    t.driver.rating ? '★ ' + t.driver.rating.toFixed(1) : 'Novo motorista',
    esc(t.driver.vehicle),
    t.available,
    t.available === 1 ? '' : 's',
    t.available === 1 ? 'l' : 'is',
    money(t.price),
    t.id,
    esc(t.event?.name)
  ]);
}

function filteredTrips() {
  let trips = state.trips.filter(
    (t) =>
      (!filters.origin ||
        t.origin.toLocaleLowerCase('pt-BR').includes(filters.origin.toLocaleLowerCase('pt-BR'))) &&
      (!filters.eventId || t.eventId === filters.eventId) &&
      (!filters.date || localDate(t.date).slice(0, 10) === filters.date) &&
      (category === 'Todos' || t.event?.category === category)
  );

  return trips.sort((a, b) =>
    sort === 'price' ? a.price - b.price : new Date(a.date) - new Date(b.date)
  );
}

function search() {
  const trips = filteredTrips();

  return html('buscar', [
    esc(filters.origin),
    eventOptions(filters.eventId),
    esc(filters.date),
    trips.length,
    trips.length === 1 ? 'viagem encontrada' : 'viagens encontradas',
    sort === 'date' ? 'selected' : '',
    sort === 'price' ? 'selected' : '',
    ['Todos', 'Música', 'Esporte', 'Cultura']
      .map((c) =>
        html('componentes/buscar-013', [
          category === c ? 'active' : '',
          c,
          category === c,
          c
        ])
      )
      .join(''),
    trips.length
      ? trips.map(tripCard).join('')
      : empty('Nenhuma carona por aqui ainda.', html('componentes/buscar-014', [])),
    state.events
      .slice(0, 3)
      .map((e) =>
        html('componentes/buscar-015', [
          e.id,
          new Date(e.date).getDate(),
          new Date(e.date).toLocaleDateString('pt-BR', { month: 'short' }).toUpperCase(),
          esc(e.name),
          esc(e.category)
        ])
      )
      .join('')
  ]);
}

function login() {
  modal(
    html('login', [
      field('E-mail', 'email', 'email', '', 'class="span2" required autocomplete="email"'),
      field('Senha', 'password', 'password', '', 'required autocomplete="current-password"'),
      errorSlot,
      ['passageiro', 'motorista', 'admin']
        .map((role) =>
          html('componentes/login-017', [
            role,
            role === 'admin' ? 'Administrador' : role === 'motorista' ? 'Motorista' : 'Passageiro'
          ])
        )
        .join('')
    ])
  );
}

function register(role = 'passageiro') {
  modal(
    html('cadastro', [
      role === 'passageiro' ? 'selected' : '',
      role === 'motorista' ? 'selected' : '',
      field('Nome completo', 'name', 'text', '', 'required maxlength="100" autocomplete="name"'),
      field('CPF', 'cpf', 'text', '', 'required inputmode="numeric" maxlength="14"'),
      field('E-mail', 'email', 'email', '', 'required autocomplete="email"'),
      field('Telefone com DDD', 'phone', 'tel', '', 'required autocomplete="tel"'),
      field('Senha (mínimo 8 caracteres)', 'password', 'password', '', 'required minlength="8" maxlength="128" autocomplete="new-password"'),
      role !== 'motorista' ? 'hidden' : '',
      field('CNH (11 dígitos)', 'cnh', 'text', '', 'inputmode="numeric" maxlength="11"'),
      field('Modelo do veículo', 'vehicle', 'text', '', 'maxlength="80"'),
      field('Placa sem hífen', 'plate', 'text', '', 'maxlength="7"'),
      field('Cor do veículo', 'color', 'text', '', 'maxlength="30"'),
      errorSlot
    ])
  );
}

function recover() {
  modal(html('recuperar-senha', [
    field('E-mail cadastrado', 'email', 'email', '', 'required'),
    errorSlot
  ]));
}

function details(id) {
  const t = state.trips.find((t) => t.id === id);

  if (!t) {
    return toast('Esta viagem não está mais disponível.');
  }

  modal(
    html('componentes/detalhes-carona-028', [
      esc(t.event.category),
      esc(t.event.name),
      fullDate(t.date),
      esc(t.origin),
      initials(t.driver.name),
      esc(t.driver.name),
      esc(t.driver.vehicle),
      esc(t.driver.color),
      t.driver.rating ? '★ ' + t.driver.rating.toFixed(1) : 'Sem avaliações',
      esc(t.destination),
      esc(t.notes || 'Confirme o ponto de encontro com o motorista.'),
      t.available,
      money(t.price),
      t.reviews.length
        ? html('componentes/detalhes-carona-022', [
            t.reviews
              .slice(-3)
              .map((r) =>
                html('componentes/detalhes-carona-021', [
                  '★'.repeat(r.rating),
                  esc(r.comment || 'Sem comentário')
                ])
              )
              .join('')
          ])
        : '',
      !state.user
        ? html('componentes/detalhes-carona-023', [])
        : state.user.role !== 'passageiro'
          ? html('componentes/detalhes-carona-024', [])
          : t.available < 1
            ? html('componentes/detalhes-carona-025', [])
            : html('detalhes-carona', [
                t.id,
                t.price,
                Array.from({ length: t.available }, (_, i) =>
                  html('componentes/detalhes-carona-026', [i + 1, i + 1, i ? 'pessoas' : 'pessoa'])
                ).join(''),
                money(t.price),
                errorSlot
              ])
    ])
  );
}

function reservations() {
  return html('componentes/reservas-034', [
    state.reservations.length
      ? state.reservations
          .slice()
          .reverse()
          .map((r) =>
            html('reservas', [
              r.status,
              r.status,
              fullDate(r.trip.date),
              esc(r.trip.event?.name),
              esc(r.trip.origin),
              esc(r.trip.destination),
              initials(r.trip.driver.name),
              esc(r.trip.driver.name),
              esc(r.trip.driver.vehicle),
              esc(r.trip.driver.color),
              esc(r.trip.notes),
              r.quantity,
              money(r.quantity * r.trip.price),
              r.id.slice(0, 8),
              r.status === 'confirmada' && r.trip.status === 'agendada' && new Date(r.trip.date) > new Date()
                ? html('componentes/reservas-029', [r.id])
                : '',
              r.status === 'confirmada' && r.trip.status === 'concluida' && !r.reviewed
                ? html('componentes/reservas-030', [r.id])
                : '',
              r.reviewed ? html('componentes/reservas-031', []) : ''
            ])
          )
          .join('')
      : empty('Sua próxima viagem está esperando.', html('componentes/reservas-033', []))
  ]);
}

function tripForm(t) {
  modal(
    html('formulario-viagem', [
      t ? 'Editar viagem' : 'Oferecer uma carona',
      t?.id || '',
      eventOptions(t?.eventId),
      field('Cidade de saída', 'origin', 'text', t?.origin || '', 'required maxlength="100"'),
      field('Destino / local do evento', 'destination', 'text', t?.destination || '', 'required maxlength="200"'),
      field('Data e hora de saída', 'date', 'datetime-local', t ? localDate(t.date) : '', 'required'),
      field('Total de vagas para passageiros', 'capacity', 'number', t?.capacity || 3, 'required min="1" max="8" step="1"'),
      field('Valor por pessoa (R$)', 'price', 'number', t?.price ?? '', 'required min="0" max="9999" step="0.01"'),
      esc(t?.notes || ''),
      errorSlot,
      t ? 'Salvar alterações' : 'Enviar para aprovação'
    ])
  );
}

function trips() {
  return html('viagens', [
    state.myTrips.length
      ? state.myTrips
          .map((t) =>
            html('componentes/viagens-039', [
              t.approval === 'aprovada' ? t.status : t.approval,
              t.approval === 'pendente'
                ? 'Aguardando aprovação'
                : t.approval === 'rejeitada'
                  ? 'Rejeitada — edite e reenvie'
                  : t.status,
              esc(t.event?.name),
              esc(t.origin),
              esc(t.destination),
              fullDate(t.date),
              t.available,
              t.capacity,
              money(t.price),
              t.passengers.length
                ? t.passengers
                    .map((p) => esc(p.name) + ' · ' + p.quantity + ' vaga(s)')
                    .join(html('componentes/viagens-036', []))
                : 'Nenhum passageiro reservado ainda.',
              t.status === 'agendada'
                ? `${new Date(t.date) > new Date()
                    ? html('componentes/viagens-037', [t.id, t.id])
                    : t.approval === 'aprovada'
                      ? html('componentes/viagens-038', [t.id])
                      : ''}`
                : ''
            ])
          )
          .join('')
      : empty('Seu próximo trajeto pode ser compartilhado.', 'Crie uma viagem para um dos eventos aprovados.'),
    table(
      ['Evento proposto', 'Data', 'Aprovação'],
      (state.myEvents || []).map((e) => [esc(e.name), fullDate(e.date), approvalLabel(e)])
    )
  ]);
}

function events() {
  return html('componentes/eventos-042', [
    state.events
      .map((e) =>
        html('eventos', [
          esc(e.category),
          date(e.date),
          esc(e.name),
          esc(e.location),
          time(e.date),
          esc(e.description),
          e.id
        ])
      )
      .join('') || empty('Nenhum evento cadastrado.', 'Volte em breve.')
  ]);
}

function profile() {
  const u = state.user;

  return html('perfil', [
    u.role === 'motorista' ? 'Motorista' : u.role === 'admin' ? 'Administrador' : 'Passageiro',
    field('Nome completo', 'name', 'text', u.name, 'required'),
    field('Telefone', 'phone', 'tel', u.phone, 'required'),
    field('E-mail', 'email', 'email', u.email, 'required'),
    field('Senha atual (para trocar a senha)', 'currentPassword', 'password', '', 'autocomplete="current-password"'),
    field('Nova senha (opcional)', 'password', 'password', '', 'minlength="8" autocomplete="new-password"'),
    u.role === 'motorista'
      ? html('componentes/perfil-043', [esc(u.vehicle), esc(u.color), esc(u.plate)])
      : '',
    errorSlot
  ]);
}

function notifications() {
  return html('notificacoes', [
    state.notifications
      .map((n) =>
        html('componentes/notificacoes-045', [
          n.read ? '' : 'unread',
          esc(n.message),
          fullDate(n.date)
        ])
      )
      .join('') || empty('Tudo em dia.', 'Suas próximas atualizações aparecerão aqui.')
  ]);
}

function table(headers, rows) {
  return rows.length
    ? html('componentes/tabela-050', [
        headers.map((h) => html('componentes/tabela-047', [h])).join(''),
        rows
          .map((c) =>
            html('componentes/tabela-049', [
              c.map((v) => html('componentes/tabela-048', [v])).join('')
            ])
          )
          .join('')
      ])
    : empty('Nenhum registro encontrado.', 'Os dados aparecerão aqui conforme a utilização.');
}

let reportStart = '',
  reportEnd = '';

function approvalLabel(record) {
  return ({
    pendente: 'Aguardando aprovação',
    aprovada: 'Aprovado',
    rejeitada: 'Rejeitado'
  })[record.approval] || 'Aprovado';
}

function approvalActions(record, kind) {
  return record.approval === 'pendente' && (kind !== 'trip' || record.status === 'agendada')
    ? html('acoes-aprovacao', [record.id, kind, record.id, kind])
    : '';
}

function adminPage() {
  const tabs = [
    ['approvals', 'Aprovações'],
    ['users', 'Usuários'],
    ['trips', 'Viagens'],
    ['events', 'Eventos'],
    ['reservations', 'Reservas'],
    ['reports', 'Relatórios']
  ];

  let body = '';

  if (adminTab === 'approvals') {
    body = table(['Tipo', 'Nome / destino', 'Data', 'Ações'], [
      ...admin.events
        .filter((e) => e.approval === 'pendente')
        .map((e) => ['Evento', esc(e.name), fullDate(e.date), approvalActions(e, 'event')]),
      ...admin.trips
        .filter((t) => t.approval === 'pendente' && t.status === 'agendada')
        .map((t) => [
          'Viagem',
          esc(t.event?.name) + ' · ' + esc(t.origin),
          fullDate(t.date),
          approvalActions(t, 'trip')
        ])
    ]);
  }

  if (adminTab === 'users') {
    body = table(['Nome / e-mail', 'Perfil', 'Status', 'Ação'],
      admin.users.map((u) => [
        html('componentes/administracao-051', [esc(u.name), esc(u.email)]),
        esc(u.role),
        u.active ? 'Ativo' : 'Bloqueado',
        u.id === state.user.id
          ? 'Sua conta'
          : html('componentes/administracao-052', [u.id, u.id, u.active ? 'Bloquear' : 'Desbloquear'])
      ])
    );
  }

  if (adminTab === 'trips') {
    body = table(['Evento', 'Motorista', 'Saída', 'Vagas', 'Status', 'Aprovação', 'Ações'],
      admin.trips.map((t) => [
        esc(t.event?.name),
        esc(t.driver.name),
        fullDate(t.date),
        t.available + '/' + t.capacity,
        esc(t.status),
        approvalLabel(t),
        html('acoes-viagem-admin', [t.id, t.id]) + approvalActions(t, 'trip')
      ])
    );
  }

  if (adminTab === 'events') {
    body =
      html('componentes/administracao-054', []) +
      table(['Evento', 'Local', 'Data', 'Aprovação', 'Ações'],
        admin.events.map((e) => [
          esc(e.name),
          esc(e.location),
          fullDate(e.date),
          approvalLabel(e),
          html('componentes/administracao-055', [e.id, e.id]) + approvalActions(e, 'event')
        ])
      );
  }

  if (adminTab === 'reservations') {
    body = table(['Passageiro', 'Destino', 'Vagas', 'Status', 'Ação'],
      admin.reservations.map((r) => [
        esc(r.name),
        esc(r.destination),
        r.quantity,
        esc(r.status),
        r.status === 'confirmada' ? html('componentes/administracao-056', [r.id]) : '—'
      ])
    );
  }

  if (adminTab === 'reports') {
    const rows = reportRows();

    body = html('componentes/administracao-057', [
      field('De', 'start', 'date', reportStart),
      field('Até', 'end', 'date', reportEnd),
      rows.length,
      table(['Data', 'Passageiro', 'Destino', 'Vagas', 'Status'],
        rows.map((r) => [
          fullDate(r.date),
          esc(r.name),
          esc(r.destination),
          r.quantity,
          esc(r.status)
        ])
      )
    ]);
  }

  return html('administracao', [
    admin.users.length,
    admin.trips.length,
    admin.reservations.filter((r) => r.status === 'confirmada').length,
    admin.events.length,
    tabs
      .map(([v, n]) =>
        html('componentes/administracao-058', [
          adminTab === v ? 'active' : '',
          v,
          adminTab === v,
          n
        ])
      )
      .join(''),
    body
  ]);
}

function reportRows() {
  return admin.reservations.filter((r) => {
    const d = localDate(r.date).slice(0, 10);
    return (!reportStart || d >= reportStart) && (!reportEnd || d <= reportEnd);
  });
}

function eventForm(e) {
  modal(
    html('formulario-evento', [
      e ? 'Editar' : 'Cadastrar',
      e?.id || '',
      field('Nome', 'name', 'text', e?.name || '', 'required'),
      field('Local', 'location', 'text', e?.location || '', 'required'),
      field('Data e hora', 'date', 'datetime-local', e ? localDate(e.date) : '', 'required'),
      ['Música', 'Esporte', 'Cultura']
        .map((c) => html('componentes/formulario-evento-060', [e?.category === c ? 'selected' : '', c]))
        .join(''),
      esc(e?.description || ''),
      errorSlot
    ])
  );
}

function confirmAction(title, message, endpoint, body) {
  modal(html('confirmacao', [title, message, endpoint, esc(JSON.stringify(body)), errorSlot]));
}

async function refresh() {
  state = await api('state');

  if (state.user?.role === 'admin' && route() === 'admin') {
    admin = await api('admin/data', {});
  }

  render();
}

function render() {
  header();
  const r = route();

  if (['reservas', 'viagens', 'perfil', 'notificacoes', 'admin'].includes(r) && !state.user) {
    $('#main').innerHTML = html('componentes/pagina-064', [
      empty('Entre para continuar.', html('componentes/pagina-063', []))
    ]);
    return;
  }

  let content;

  if (r === 'buscar') {
    content = search();
  } else if (r === 'eventos') {
    content = events();
  } else if (r === 'reservas' && state.user?.role === 'passageiro') {
    content = reservations();
  } else if (r === 'viagens' && state.user?.role === 'motorista') {
    content = trips();
  } else if (r === 'perfil') {
    content = profile();
  } else if (r === 'notificacoes') {
    content = notifications();
  } else if (r === 'admin' && state.user?.role === 'admin' && admin) {
    content = adminPage();
  } else {
    content = html('componentes/pagina-066', [
      empty('Esta área não está disponível para o seu perfil.', html('componentes/pagina-065', []))
    ]);
  }

  $('#main').innerHTML = html('componentes/pagina-067', [content]);
}

document.addEventListener('click', async (e) => {
  const button = e.target.closest('[data-action]');

  if (!button) {
    return;
  }

  const { action, id, value } = button.dataset;

  try {
    if (action === 'retry') {
      await refresh();
      toast('Conexão restabelecida.');
    }

    if (action === 'login') {
      login();
    }

    if (action === 'register') {
      register();
    }

    if (action === 'recover') {
      recover();
    }

    if (action === 'close') {
      close();
    }

    if (action === 'demo') {
      const f = $('#login-form');
      f.email.value = value + '@caronahub.local';
      f.password.value = 'Carona@123';
      f.requestSubmit();
    }

    if (action === 'logout') {
      await api('logout', {});
      location.hash = 'buscar';
      await refresh();
      toast('Você saiu da sua conta.');
    }

    if (action === 'category') {
      category = value;
      render();
    }

    if (action === 'clear') {
      filters = { origin: '', eventId: '', date: '' };
      category = 'Todos';
      render();
    }

    if (action === 'event-filter') {
      filters = { origin: '', eventId: id, date: '' };
      category = 'Todos';
      location.hash = 'buscar';
      render();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    if (action === 'details') {
      details(id);
    }

    if (action === 'offer') {
      if (!state.user) {
        register('motorista');
      } else if (state.user.role === 'motorista') {
        tripForm();
      } else {
        toast('Entre com uma conta de motorista para oferecer caronas.');
      }
    }

    if (action === 'approve' || action === 'reject') {
      confirmAction(
        action === 'approve' ? 'Aprovar publicação?' : 'Rejeitar publicação?',
        action === 'approve'
          ? 'O registro ficará disponível aos usuários após a aprovação.'
          : 'O autor receberá uma notificação.',
        'admin/moderate',
        { id, kind: button.dataset.kind, approval: action === 'approve' ? 'aprovada' : 'rejeitada' }
      );
    }

    if (action === 'delete-trip') {
      confirmAction(
        'Excluir esta viagem?',
        'A viagem será removida das listagens. As reservas serão canceladas e os envolvidos serão notificados. O histórico será preservado.',
        'admin/trip/delete',
        { id }
      );
    }

    if (action === 'new-trip') {
      tripForm();
    }

    if (action === 'edit-trip') {
      tripForm(state.myTrips.find((t) => t.id === id) || admin?.trips.find((t) => t.id === id));
    }

    if (action === 'cancel-trip') {
      confirmAction(
        'Cancelar esta viagem?',
        'As reservas serão canceladas e os passageiros receberão uma notificação.',
        'trips/status',
        { id, status: 'cancelada' }
      );
    }

    if (action === 'complete-trip') {
      confirmAction(
        'Concluir esta viagem?',
        'Após concluir, os passageiros poderão avaliar o trajeto.',
        'trips/status',
        { id, status: 'concluida' }
      );
    }

    if (action === 'cancel-reservation') {
      confirmAction(
        'Cancelar esta reserva?',
        'As vagas serão devolvidas à viagem e os envolvidos serão notificados.',
        'reservations/cancel',
        { id }
      );
    }

    if (action === 'review') {
      modal(
        html('componentes/pagina-069', [
          id,
          [5, 4, 3, 2, 1]
            .map((n) =>
              html('componentes/pagina-068', [n, n, n === 1 ? 'estrela' : 'estrelas'])
            )
            .join(''),
          errorSlot
        ])
      );
    }

    if (action === 'read-notifications') {
      await api('notifications/read', {});
      await refresh();
      toast('Notificações marcadas como lidas.');
    }

    if (action === 'admin-tab') {
      adminTab = value;
      render();
    }

    if (action === 'toggle-user') {
      confirmAction(
        'Alterar acesso do usuário?',
        'O bloqueio encerra as sessões e impede novos acessos.',
        'admin/user',
        { id }
      );
    }

    if (action === 'edit-user') {
      const u = admin.users.find((u) => u.id === id);
      modal(
        html('componentes/pagina-070', [
          u.id,
          field('Nome', 'name', 'text', u.name, 'required'),
          field('E-mail', 'email', 'email', u.email, 'required'),
          field('Telefone', 'phone', 'tel', u.phone, 'required'),
          errorSlot
        ])
      );
    }

    if (action === 'new-event') {
      eventForm();
    }

    if (action === 'edit-event') {
      eventForm(admin.events.find((e) => e.id === id));
    }

    if (action === 'delete-event') {
      confirmAction(
        'Excluir evento?',
        'Só é possível excluir eventos sem viagens vinculadas.',
        'admin/event',
        { id, remove: true }
      );
    }

    if (action === 'print') {
      window.print();
    }

    if (action === 'csv') {
      const cell = (v) =>
        '"' + String(v ?? '').replace(/^[=+@-]/, "'$&").replaceAll('"', '""') + '"';

      const csv = [
        ['Data', 'Passageiro', 'Destino', 'Vagas', 'Status'],
        ...reportRows().map((r) => [fullDate(r.date), r.name, r.destination, r.quantity, r.status])
      ]
        .map((row) => row.map(cell).join(';'))
        .join('\r\n');

      const url = URL.createObjectURL(
        new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
      );

      const a = document.createElement('a');
      a.href = url;
      a.download = 'carona-hub-reservas.csv';
      a.click();

      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
  } catch (err) {
    toast(err.message);
  }
});

document.addEventListener('change', (e) => {
  if (e.target.id === 'register-role') {
    $('#driver-fields').hidden = e.target.value !== 'motorista';
    $('#driver-fields')
      .querySelectorAll('input')
      .forEach((i) => {
        i.required = e.target.value === 'motorista';
      });
  }

  if (e.target.id === 'sort') {
    sort = e.target.value;
    render();
  }

  if (e.target.id === 'quantity') {
    $('#total').textContent = money(Number(e.target.value) * Number(e.target.dataset.price));
  }

  if (e.target.name === 'eventId' && e.target.closest('#trip-form')) {
    const event = state.events.find((x) => x.id === e.target.value);

    if (event) {
      $('#trip-form').destination.value = event.location;
    }
  }
});

document.addEventListener('submit', async (e) => {
  const f = e.target;

  if (!(f instanceof HTMLFormElement)) {
    return;
  }

  e.preventDefault();
  const data = Object.fromEntries(new FormData(f));

  if (f.getAttribute('id') === 'search-form') {
    filters = data;
    render();
    return;
  }

  if (f.getAttribute('id') === 'report-form') {
    if (data.start && data.end && data.start > data.end) {
      toast('A data final deve ser igual ou posterior à inicial.');
      return;
    }

    reportStart = data.start;
    reportEnd = data.end;
    render();
    return;
  }

  const submit = f.querySelector('button[type="submit"],button:not([type])');

  if (submit) {
    submit.disabled = true;
  }

  const error = f.querySelector('.form-error');

  if (error) {
    error.textContent = '';
  }

  try {
    let endpoint = ({
      'login-form': 'login',
      'register-form': 'register',
      'recover-form': 'recover',
      'reset-form': 'reset',
      'profile-form': 'profile',
      'trip-form': 'trips/save',
      'reserve-form': 'reserve',
      'review-form': 'reviews',
      'event-form': state.user?.role === 'admin' ? 'admin/event' : 'events/save',
      'admin-user-form': 'admin/user/save'
    })[f.getAttribute('id')];

    let body = data;

    if (f.getAttribute('id') === 'confirm-form') {
      endpoint = data.endpoint;
      body = JSON.parse(data.payload);
    }

    if (!endpoint) {
      return;
    }

    const result = await api(endpoint, body);

    if (f.getAttribute('id') === 'register-form') {
      login();
      toast(result.message);
      return;
    }

    if (f.getAttribute('id') === 'recover-form') {
      modal(html('componentes/pagina-071', [esc(result.message)]));
      return;
    }

    close();

    if (f.getAttribute('id') === 'reserve-form') {
      location.hash = 'reservas';
    }

    if (f.getAttribute('id') === 'event-form' && state.user.role === 'motorista') {
      location.hash = 'viagens';
    }

    if (f.getAttribute('id') === 'trip-form' && state.user.role === 'motorista') {
      location.hash = 'viagens';
    }

    if (f.getAttribute('id') === 'reset-form') {
      history.replaceState(null, '', location.pathname);
      login();
    }

    await refresh();
    toast(result.message || 'Atualização concluída.');
  } catch (err) {
    if (error) {
      error.textContent = err.message;
    } else {
      toast(err.message);
    }
  } finally {
    if (submit) {
      submit.disabled = false;
    }
  }
});

window.addEventListener('hashchange', () => {
  if (location.hash === '#main') {
    return;
  }

  refresh().catch(connectionFailure);
});

try {
  await refresh();
  const token = new URLSearchParams(location.search).get('reset');

  if (token) {
    modal(
      html('componentes/pagina-072', [
        esc(token),
        field('Nova senha', 'password', 'password', '', 'required minlength="8" maxlength="128" autocomplete="new-password"'),
        errorSlot
      ])
    );
  }
} catch (e) {
  connectionFailure(e);
}

if (document.modelContext?.registerTool) {
  const lifecycle = new AbortController();
  window.addEventListener('pagehide', () => lifecycle.abort(), { once: true });

  try {
    await document.modelContext.registerTool(
      {
        name: 'filter_available_caronas',
        title: 'Filtrar caronas disponíveis',
        description:
          'Aplica os filtros de cidade e evento à busca visível e retorna as caronas encontradas. Não realiza reservas.',
        inputSchema: {
          type: 'object',
          properties: {
            origin: { type: 'string' },
            eventId: { type: 'string' }
          },
          additionalProperties: false
        },
        annotations: {
          readOnlyHint: false,
          untrustedContentHint: true
        },
        async execute(input) {
          if (
            !input ||
            typeof input !== 'object' ||
            Object.keys(input).some((k) => !['origin', 'eventId'].includes(k)) ||
            Object.values(input).some((v) => typeof v !== 'string')
          ) {
            throw Error('Filtros inválidos.');
          }

          await refresh();

          if (input.eventId && !state.events.some((e) => e.id === input.eventId)) {
            throw Error('Evento não encontrado.');
          }

          filters = { origin: input.origin || '', eventId: input.eventId || '', date: '' };
          category = 'Todos';
          location.hash = 'buscar';
          render();

          return {
            trips: filteredTrips().map((t) => ({
              id: t.id,
              event: t.event.name,
              origin: t.origin,
              date: t.date,
              available: t.available,
              price: t.price
            }))
          };
        }
      },
      { signal: lifecycle.signal }
    );
  } catch {
    console.info('Integração opcional com agentes indisponível.');
  }
}
