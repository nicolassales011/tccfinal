const arquivos = new Map();

export async function carregarHTML() {
  try {
    const manifest = await fetch('/html/manifest.json');

    if (!manifest.ok) {
      throw new Error('Lista de arquivos HTML indisponível.');
    }

    const nomes = await manifest.json();

    await Promise.all(
      nomes.map(async (nome) => {
        const resposta = await fetch(`/html/${nome}.html`);

        if (!resposta.ok) {
          throw new Error(`Arquivo HTML não encontrado: ${nome}`);
        }

        arquivos.set(nome, await resposta.text());
      })
    );
  } catch (erro) {
    document.querySelector('#main').textContent =
      'Não foi possível carregar as telas. Execute node start.js, mantenha o terminal aberto e atualize a página. ' +
      erro.message;

    throw erro;
  }
}
export function html(nome, valores = []) {
  if (!arquivos.has(nome)) {
    throw new Error(`Tela não carregada: ${nome}`);
  }

  return arquivos
    .get(nome)
    .replace(/\{\{(\d+)\}\}/g, (_, indice) => String(valores[Number(indice)] ?? ''));
}